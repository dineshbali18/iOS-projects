//
//  ViewController.swift
//  BaliTableView
//
//  Created by Dinesh Bali on 11/14/24.
//

import UIKit

class Contact {
    var name:String?
    var department:String?
    var phoneNum:String?
    var office:String?
    
    init(name: String? = nil, department: String? = nil, phoneNum: String? = nil, office: String? = nil) {
        self.name = name
        self.department = department
        self.phoneNum = phoneNum
        self.office = office
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //returns the number of records..
        return contacts.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        // populate a cell
        
        cell.textLabel?.text = contacts[indexPath.row].name
        
        
        //return a cell
        return cell;
    }
    

    var contacts = [Contact]()
    @IBOutlet weak var tableViewOL: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        tableViewOL.delegate=self;
        tableViewOL.dataSource=self;
        
        let c1 = Contact(name:"Dinesh",department: "CS",phoneNum: "9121085044",office: "CH 3300")
        let c2 = Contact(name:"Bali",department: "AP CM🤣",phoneNum: "9121085040",office: "CH 3310")
        let c3 = Contact(name:"Vijay",department: "Tamil CM",phoneNum: "9121085041",office: "CH 3320")
        let c4 = Contact(name:"Mahesh",department: "Actor",phoneNum: "9121085042",office: "CH 3330")
        let c5 = Contact(name:"Ram",department: "Actor",phoneNum: "9121085043",office: "CH 3340")
        
        contacts.append(c1);
        contacts.append(c2);
        contacts.append(c3);
        contacts.append(c4);
        contacts.append(c5);
        
        //sort the contacts
        contacts = contacts.sorted(by: {$0.name! < $1.name!})
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue" {
            var destination = segue.destination as! ResultViewController
            
            //assign the selected row contacts
            //to the destination
            destination.contact = contacts[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }


}

