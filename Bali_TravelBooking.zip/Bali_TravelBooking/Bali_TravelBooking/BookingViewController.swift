//
//  ViewController.swift
//  Bali_TravelBooking
//
//  Created by Dinesh Bali on 11/16/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    var image = "";
    var travellersName = "";
    var noOfTravellers = "";
    var cabinType = "";
    var result = "";
    var totalCost = 0.0;
    
    @IBOutlet weak var travellerNameOL: UITextField!
    
    @IBOutlet weak var noOfTravellersOL: UITextField!
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }


    @IBAction func bookNowButton(_ sender: Any) {
        travellersName = travellerNameOL.text ?? ""
        noOfTravellers = noOfTravellersOL.text ?? ""
        cabinType = cabinTypeOL.text?.lowercased() ?? ""
                        
        if let travellers = Int(noOfTravellers) {
            var costPerPerson = 0
            image = ""
            
            if cabinType == "economy" {
                costPerPerson = 150
                image = "economy"
            } else if cabinType == "luxury" {
                costPerPerson = 250
                image = "luxury"
            } else {
                image = "notvalid"
            }

            totalCost = Double(travellers * costPerPerson)
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! BaliResultViewController;
            
            destination.image = image;
            destination.travellersName = travellersName;
            destination.noOfTravellers = noOfTravellers;
            destination.cabinType = cabinType;
            destination.result = result;
            destination.totalCost = Double(totalCost);
        
        }
        
    }
}

