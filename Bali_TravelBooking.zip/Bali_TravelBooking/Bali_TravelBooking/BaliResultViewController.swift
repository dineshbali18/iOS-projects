//
//  BaliResultViewController.swift
//  Bali_TravelBooking
//
//  Created by Dinesh Bali on 11/16/24.
//

import UIKit

class BaliResultViewController: UIViewController {

    var image = "";
    var result = "";
    var travellersName = "";
    var noOfTravellers = "";
    var cabinType = "";
    var totalCost = 0.0;
    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var resultOL: UILabel!

    @IBOutlet weak var travellerNameOL: UILabel!
    
    @IBOutlet weak var noOfTravellersOL: UILabel!
    
    @IBOutlet weak var cabinTypeOL: UILabel!
    
    @IBOutlet weak var totalCostOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        imageOL.image = UIImage(named: image)
                
        if cabinType == "economy" || cabinType == "luxury" {
            imageOL.image = UIImage(named: image)
            resultOL.text = "Hello \(travellersName),\nYour booking is confirmed."
            travellerNameOL.text = "Name: \(travellersName)"
            noOfTravellersOL.text = "Number of Travellers: \(noOfTravellers)"
            cabinTypeOL.text = "Cabin class: \(cabinType)"
            totalCostOL.text = String(format: "Total: %.1f$", totalCost)
        } else {
            imageOL.image = UIImage(named: image)
            resultOL.text = "There is no selected class. \nPlease choose a valid class."
            travellerNameOL.isHidden = true
            noOfTravellersOL.isHidden = true
            cabinTypeOL.isHidden = true
            totalCostOL.isHidden = true
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
