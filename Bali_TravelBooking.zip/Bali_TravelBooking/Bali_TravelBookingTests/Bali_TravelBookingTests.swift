//
//  Bali_TravelBookingTests.swift
//  Bali_TravelBookingTests
//
//  Created by Dinesh Bali on 11/16/24.
//

import Testing
@testable import Bali_TravelBooking

struct Bali_TravelBookingTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
