//
//  Bali_Exam02Tests.swift
//  Bali_Exam02Tests
//
//  Created by Dinesh Bali on 11/7/24.
//

import Testing
@testable import Bali_Exam02

struct Bali_Exam02Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
