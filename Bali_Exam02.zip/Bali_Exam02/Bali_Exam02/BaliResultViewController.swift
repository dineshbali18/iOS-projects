//
//  BaliResultViewController.swift
//  Bali_Exam02
//
//  Created by Dinesh Bali on 11/7/24.
//

import UIKit

class BaliResultViewController: UIViewController {

    
    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var paymentHistoryOL: UILabel!
    
    
    @IBOutlet weak var creditUtilizationOL: UILabel!
    
    
    @IBOutlet weak var creditScoreOL: UILabel!
    
    
    @IBOutlet weak var resultOL: UILabel!
    
    
    @IBOutlet weak var creditScopeOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    var name=""
    var paymentHistory=""
    var creditUtilization=""
    var creditScore=0;
    var image=""
    var result=""
    var creditScope=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

        nameOL.text! += " \(name)"
        paymentHistoryOL.text! += " \(paymentHistory)"
        creditUtilizationOL.text! += " \(creditUtilization)"
        creditScoreOL.text! += " \(creditScore)"
        creditScopeOL.text! += " \(creditScope)"
        resultOL.text! += " \(result)"
        imageOL.image = UIImage(named: image)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
