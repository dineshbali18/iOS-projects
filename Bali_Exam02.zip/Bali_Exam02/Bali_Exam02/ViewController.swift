//
//  ViewController.swift
//  Bali_Exam02
//
//  Created by Dinesh Bali on 11/7/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var customerNameOL: UITextField!
    
    
    @IBOutlet weak var customerHistoryRatingOL: UITextField!
    
    
    @IBOutlet weak var creditUtilizationOL: UITextField!
    
    @IBOutlet weak var computeCreditBtn: UIButton!
    
    
    @IBOutlet weak var resetBtn: UIButton!
    
    
    var check=false;
    var check1=0;
    var check2=0;
    var check3=0;
    var checkFinal=0;
    var creditScore=0.0;
    var image=""
    var result=""
    var creditScope=""
    
    
    var estimatedCreditScore=0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if(customerNameOL.text! == "" && customerHistoryRatingOL.text! == "" && creditUtilizationOL.text! == ""){
            computeCreditBtn.isEnabled = false;
            resetBtn.isEnabled = false;
        }else{
            computeCreditBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    
    @IBAction func onCustomerNameChange(_ sender: Any) {
        if customerNameOL.text! != ""{
            check1=1;
        }
        checkFinal = check1+check2+check3;
        if(checkFinal==3){
            computeCreditBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    
    @IBAction func onPaymentHistoryChanged(_ sender: Any) {
        print(customerHistoryRatingOL.text!)
        if customerHistoryRatingOL.text! != ""{
            check2=1;
        }
        checkFinal = check1+check2+check3;
        if(checkFinal==3){
            computeCreditBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    
    @IBAction func onCreditUtilizationChanged(_ sender: Any) {
        if creditUtilizationOL.text! != ""{
            check3=1;
        }
        checkFinal = check1+check2+check3;
        if(checkFinal==3){
            computeCreditBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    @IBAction func onClickReset(_ sender: Any) {
        customerNameOL.text! = ""
        creditUtilizationOL.text! = ""
        customerHistoryRatingOL.text! = ""
        check1=0;
        check2=0;
        check3=0;
        checkFinal=0;
        computeCreditBtn.isEnabled=false;
    }
    

    @IBAction func computeCredit(_ sender: Any) {
        estimatedCreditScore = 300 + (0.583*Double(customerHistoryRatingOL.text!)!)+(0.5*Double(creditUtilizationOL.text!)!)
        creditScore = Double(estimatedCreditScore)
        if estimatedCreditScore>=800 && estimatedCreditScore<=850 {
            result = "Excellent";
            creditScope = "Individuals in this range are considered to be at the lowest risk. They have a history of making payments on time and keeping credit utilization low. They’re eligible for the best interest rates and credit products 🏦 🏦✅."
            image = "800-850"
        }
        else if estimatedCreditScore>=740 && estimatedCreditScore<=799{
            result = "Very Good";
            creditScope = "Still a very desirable range with minimal risk. Borrowers with scores in this category are likely to qualify for favorable rates and terms 💸."
            image = "740-799"
        }else if estimatedCreditScore>=670 && estimatedCreditScore<=739{
            result = "Good";
            creditScope = "This is considered an acceptable credit score range. People with scores in this range are generally approved for credit but may not receive the lowest interest rates 💳."
            image = "670-739"
        }else if estimatedCreditScore>=580 && estimatedCreditScore<=669{
            result = "Fair";
            creditScope = "This range indicates higher credit risk. People with scores in this range may have had missed payments or higher credit utilization. They may qualify for credit, but it usually comes with higher interest rates or less favorable terms%  ⤴️⤴️⚠️🟡."
            image = "580-669"
        }else if estimatedCreditScore>=300 && estimatedCreditScore<=579{
            result = "Poor";
            creditScope = "The lowest category, indicating significant credit risk. Borrowers in this range may have a history of missed payments, high utilization, or other negative factors. They often find it challenging to obtain credit and may be subject to very high interest rates if they do qualify %⤴⤴⤴️🛑⚠️⚠️."
            image = "300-579"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "resultSegue" {
            let destination = segue.destination as! BaliResultViewController;
            
            destination.image = image
            destination.name = customerNameOL.text!
            destination.paymentHistory = customerHistoryRatingOL.text!
            destination.creditScope = creditScope
            destination.creditUtilization = creditUtilizationOL.text!
            destination.creditScore = Int(estimatedCreditScore)
            destination.result = result
    
        }
    }
}

