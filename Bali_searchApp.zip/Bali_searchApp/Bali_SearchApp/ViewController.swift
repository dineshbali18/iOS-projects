//
//  ViewController.swift
//  Bali_searchApp
//
//  Created by Dinesh Bali on 11/6/24.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var prevButton: UIButton!
    
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var searchButton: UIButton!
    
    
    @IBOutlet weak var resetButton: UIButton!
    
    let searchBtn_sound_id: SystemSoundID = 1113
        let prevBtn_sound_id: SystemSoundID = 1105
        let nextBtn_sound_id: SystemSoundID = 1105
        let resetBtn_sound_id: SystemSoundID = 1111
    
        var arrayofArrayOfImages = [
            ["fortnite", "WhatTheFog", "subway"],
            ["ronaldo", "messi", "jr"],
            ["elonmusk", "jeffb", "warren"],
            ["eee", "tiger", "wha"],
            ["vi", "sach", "dhoni"],
            ["bali","and","goa"]
        ]
        
        var games_keywords = ["contest", "play", "match", "league"]
        var sports_keywords = ["game", "fitness", "exercise", "athletics"]
    var business_keywords = ["commerce", "trade", "industry", "enterprise", "venture"];
    var leader_keywords = ["leadership", "executive", "chief", "director"];
    var cricket_keywords = ["cricket", "bowling","match", "tournament"];
    
    var places_keywords = ["islands","beaches","sea","ship"]
    
    var topics_array = [
        [
            "Fortnite is an immensely popular battle royale game developed by Epic Games, where players are dropped onto an island and fight until only one remains. Known for its vibrant art style and unique building mechanics, Fortnite has become a cultural phenomenon, especially among younger audiences.",
            "Subway Surfers is an endless runner game developed by Kiloo and SYBO Games. Players take on the role of a young graffiti artist who runs through subway tracks while avoiding trains and obstacles. Its colorful, fast-paced gameplay and global location updates keep it fresh for players worldwide.",
            "WhatTheFog is a trivia game that blends fog-of-war mechanics with interactive multiplayer gameplay. Players answer trivia questions while navigating a foggy map, uncovering areas as they progress, which creates an engaging mix of strategy and knowledge."
        ],
        [
            "Lionel Messi is considered one of the greatest footballers of all time. The Argentine forward has won numerous Ballon d'Or titles and has broken multiple records, including becoming the top scorer for both FC Barcelona and the Argentina national team.",
            "Cristiano Ronaldo is a Portuguese forward who has achieved remarkable success in multiple leagues, including the Premier League, La Liga, and Serie A. Known for his incredible athleticism and goal-scoring ability, Ronaldo is considered one of the greatest football players ever.",
            "Neymar Jr. is a Brazilian forward known for his flair, skillful dribbling, and ability to score. He has been a key player for clubs like Barcelona and Paris Saint-Germain, and he's also a vital part of the Brazil national team."
        ],
        [
            "Elon Musk is the founder of SpaceX and Tesla, and a key figure in various industries like electric vehicles, space exploration, and AI technology. Musk’s vision for a sustainable future and his innovation in transportation and space travel have made him a controversial yet highly influential business magnate.",
            "Jeff Bezos is the founder of Amazon, the world’s largest online retailer. Under his leadership, Amazon transformed from a small online bookstore to a global e-commerce and cloud computing giant. Bezos is also known for his space exploration venture, Blue Origin.",
            "Warren Buffett, often called the ‘Oracle of Omaha,’ is a legendary investor and the chairman and CEO of Berkshire Hathaway. Known for his value investing strategy, Buffett has amassed a fortune and remains one of the richest people in the world."
        ],
        [
            "The African Elephant is the largest land animal on Earth. Known for its intelligence, strong social structures, and long lifespan, elephants are a symbol of wildlife conservation. Their tusks, however, have unfortunately made them targets for poaching.",
            "The Bengal Tiger, native to the Indian subcontinent, is a majestic and powerful predator. Its distinct orange coat with black stripes is iconic, and it plays a crucial role in maintaining the balance of the ecosystem by controlling prey populations.",
            "The Blue Whale is the largest animal to ever have lived on Earth, reaching lengths of over 100 feet. These marine giants are known for their incredible size, but they also play an important role in marine ecosystems by helping to regulate the food chain in the oceans."
        ],
        [
            "Virat Kohli is one of India’s most successful cricketers, known for his aggressive batting style. As the former captain of the Indian national team, Kohli led India to numerous victories in international cricket, earning a reputation as one of the best modern-day batsmen.",
            "Sachin Tendulkar, often referred to as the ‘God of Cricket,’ holds numerous cricketing records, including the most runs in both Tests and One Day Internationals (ODIs). His career spanned over two decades, making him an icon in the world of cricket.",
            "MS Dhoni is a former captain of the Indian cricket team and one of the most successful cricketers in history. Known for his calm demeanor and finishing skills, Dhoni led India to victories in major tournaments, including the ICC T20 World Cup, ICC World Cup 2011, and the ICC Champions Trophy 2013."
        ],
        [
                "Bali is an Indonesian island known for its lush landscapes, iconic rice terraces, and stunning beaches. Famous for its temples and vibrant culture, Bali attracts travelers with its unique blend of spiritual sites, vibrant nightlife, and natural beauty, making it a top destination for both relaxation and adventure.",
                "The Andaman Islands are a group of islands in the Bay of Bengal, known for their pristine beaches, crystal-clear waters, and rich biodiversity. Popular for snorkeling, scuba diving, and exploring remote tropical rainforests, these islands are an ideal escape for nature lovers and those seeking tranquility.",
                "Goa is a coastal state in India famous for its sandy beaches, Portuguese-influenced architecture, and vibrant tourism industry. With a lively mix of relaxation, party culture, and historical landmarks, Goa is popular for its nightlife, spice plantations, and picturesque coastline."
            ]
    ];
        var currentTopic = -1
        var currentImageIndex = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        resultImage.image = UIImage(named: "wel.jpg")
        topicInfoText.text = "Hello, Dinesh Bali !!"
        resetButton.isHidden = true;
        nextButton.isHidden = true;
        prevButton.isHidden = true;
        searchButton.isEnabled = true
    }
    
    @IBAction func searchButtonAction(_ sender: Any) {
        resetButton.isHidden = false;
        nextButton.isHidden = false;
        prevButton.isHidden = false;
        AudioServicesPlaySystemSound(searchBtn_sound_id)
           guard let searchText = searchTextField.text?.lowercased(), !searchText.isEmpty else { return }
           
           if games_keywords.contains(searchText) {
               currentTopic = 0
           } else if sports_keywords.contains(searchText) {
               currentTopic = 1
           } else if business_keywords.contains(searchText) {
               currentTopic = 2
           } else if leader_keywords.contains(searchText) {
               currentTopic = 3
           } else if cricket_keywords.contains(searchText) {
               currentTopic = 4
           }else if places_keywords.contains(searchText){
               currentTopic = 5
           } else {
               resultImage.image = UIImage(named: "not_found.jpg")
               topicInfoText.text = ""
               resetButton.isHidden = true;
               nextButton.isHidden = true;
               prevButton.isHidden = true;
               return
           }
           currentImageIndex = 0
           displayImage()
           resetButton.isEnabled = true
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        AudioServicesPlaySystemSound(prevBtn_sound_id)
        if currentTopic >= 0 && currentImageIndex > 0 {
                    currentImageIndex -= 1
                    displayImage()
                }
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        AudioServicesPlaySystemSound(resetBtn_sound_id)
        currentTopic = -1
                currentImageIndex = 0
                resultImage.image = UIImage(named: "wel.jpg")
                topicInfoText.text = "Hello, Dinesh Bali!!"
                searchTextField.text = ""
                resetButton.isHidden = true;
                nextButton.isHidden = true;
                prevButton.isHidden = true;
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        AudioServicesPlaySystemSound(nextBtn_sound_id)
        if currentTopic >= 0 && currentImageIndex < arrayofArrayOfImages[currentTopic].count - 1 {
                    currentImageIndex += 1
                    displayImage()
                }
    }
    func displayImage() {
            if currentTopic >= 0 {
                let imageName = arrayofArrayOfImages[currentTopic][currentImageIndex]
                resultImage.image = UIImage(named: imageName)
                topicInfoText.text = topics_array[currentTopic][currentImageIndex]
            }
            BtnsUpdate()
        }
        
        func BtnsUpdate() {
            // Enable/disable Next and Prev buttons based on position
            nextButton.isEnabled = currentTopic >= 0 && currentImageIndex < arrayofArrayOfImages[currentTopic].count - 1
            prevButton.isEnabled = currentTopic >= 0 && currentImageIndex > 0
            
            // Enable search button only if text field has text
            searchButton.isEnabled = !(searchTextField.text?.isEmpty ?? false)
        }
        
        
    
    @IBAction func searchTextFieldChanged(_ sender: Any) {
        BtnsUpdate()
    }


}

