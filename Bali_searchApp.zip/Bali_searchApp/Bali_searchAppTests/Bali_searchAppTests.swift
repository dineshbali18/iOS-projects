//
//  Bali_searchAppTests.swift
//  Bali_searchAppTests
//
//  Created by Dinesh Bali on 11/6/24.
//

import Testing
@testable import Bali_searchApp

struct Bali_searchAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
