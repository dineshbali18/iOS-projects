//
//  ViewController .swift
//  Bali_WordGuess
//
//  Created by Dinesh Bali on 10/22/24.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    @IBOutlet weak var totalWordsLabel: UILabel!
    @IBOutlet weak var userGuessLabel: UILabel!
    @IBOutlet weak var guessLetterField: UITextField!
    @IBOutlet weak var guessALetterButton: UIButton!
    @IBOutlet weak var hintLabel: UILabel!
    @IBOutlet weak var guessCountLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var displayImage: UIImageView!
    @IBOutlet weak var playAgainButton: UIButton!
    
    var answers = [["DINESH","Bali"],
                         ["CAT","Animal"],
                   ["JAVA","Programming Language"],
                   ["APPLE","FRUIT"],
                   ["BIKE","AUTOMOBILE"],
                   ["SAMSUNG","PHONE COMPANY"]
                         ]
    
    var assets = ["name.png","cat.png","java.png","apple.png","bike.png","samsung.png","welldone.jpeg"]
    
    var countOfGuesses = 0
    var word = ""
    var hint = ""
    var image = ""
    var guessedCount = 0
    var remainingWords = 0
    var wromgGuessesCount = 10
    var wrongCount = 0
    var currentInput = ""
    var displayedAnswer = ""
    var rightAnswers = [Character]()
    var check=0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guessedCount = 0
        countOfGuesses = 0
        remainingWords = answers.count
        contentChange()
        statusLabel.text = ""
        guessCountLabel.text = "You have made \(countOfGuesses) guesses"
        guessLetterField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        guessALetterButton.isEnabled = false
        playAgainButton.isHidden = false
        wordsGuessedLabel.text = "Total number of words guessed successfully: \(guessedCount)"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(answers.count - guessedCount)"
        totalWordsLabel.text = "Total number of words in game: \(answers.count)"
        hintLabel.isHidden = false
        userGuessLabel.isHidden = false
    }
    
    func contentChange() {
        if guessedCount < answers.count {
            let wordIndex = guessedCount
            word = answers[wordIndex][0]
            hint = answers[wordIndex][1]
            image = assets[wordIndex]
            displayedAnswer = String(repeating: "_ ", count: word.count)
            rightAnswers.removeAll()
            wordsGuessedLabel.text = "Total number of words guessed successfully: \(guessedCount)"
            wordsRemainingLabel.text = "Total number of words remaining in game: \(answers.count - guessedCount)"
            totalWordsLabel.text = "Total number of words in game: \(answers.count)"
            userGuessLabel.text = displayedAnswer
            hintLabel.text = "Hint: \(hint)"
            playAgainButton.isHidden = true
            displayImage.isHidden = true
        } else {
            hintLabel.isHidden = true
            guessCountLabel.isHidden = true
            statusLabel.text = "Congratulations! You have guessed all the words."
            displayImage.isHidden = false
            displayImage.image = UIImage(named: assets[assets.count-1])
            playAgainButton.isHidden = false
        }
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        if textField.text?.isEmpty == true {
            guessALetterButton.isEnabled = false
        } else {
            guessALetterButton.isEnabled = true
        }
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        countOfGuesses += 1
        let singleCharGuess : String
        guessCountLabel.text = "You have made \(countOfGuesses) guesses"
        if let guess = guessLetterField.text?.uppercased(), guess.count >= 1 {
            if guess.count > 1 {
                singleCharGuess = String(guess.last!)
                } else {
                    singleCharGuess = guess
                }
            currentInput = singleCharGuess
            let guessedChar = Character(currentInput)
            var isCorrectGuess = false
            var newDisplayedWord = ""
            for (_, letter) in word.enumerated() {
                if letter == guessedChar {
                    newDisplayedWord += "\(letter) "
                    rightAnswers.append(guessedChar)
                    isCorrectGuess = true
                } else if rightAnswers.contains(letter) {
                    newDisplayedWord += "\(letter) "
                } else {
                    newDisplayedWord += "_ "
                }
            }
            displayedAnswer = newDisplayedWord.trimmingCharacters(in: .whitespaces)
            userGuessLabel.text = displayedAnswer
            if isCorrectGuess {
                if displayedAnswer.replacingOccurrences(of: " ", with: "") == word {
                    guessedCount += 1
                    remainingWords = answers.count - guessedCount
                    displayImage.image = UIImage(named: image)
                    guessCountLabel.text = "Wow! You have made \(countOfGuesses) guesses to \nguess the word!"
                    displayImage.isHidden = false
                    playAgainButton.isHidden = false
                    hintLabel.isHidden = false
                    wordsGuessedLabel.text = "Total number of words guessed successfully: \(guessedCount)"
                    wordsRemainingLabel.text = "Total number of words remaining in game: \(remainingWords)"
                }
            }
            
            if countOfGuesses >= wromgGuessesCount {
                hintLabel.isHidden = true
                guessCountLabel.text = "You have used all the available \nguesses, Please play again"
                playAgainButton.isHidden = false
            }
        }
        
        guessLetterField.text = ""
        guessALetterButton.isEnabled = false
    }

    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        if(check==1){
            contentChange()
            viewDidLoad()
            check=0;
            guessCountLabel.isHidden = false;
        }else{
            hintLabel.isHidden = false
            if guessedCount < answers.count {
                wrongCount = 0
                rightAnswers.removeAll()
                contentChange()
            } else {
                hintLabel.isHidden = true
                guessCountLabel.isHidden = true
                userGuessLabel.isHidden = true
                statusLabel.text = "Congratulations! You Win! \nPlease play again"
                displayImage.image = UIImage(named: "welldone")
                playAgainButton.isHidden = false
            }
            countOfGuesses = 0
            guessCountLabel.text = "You have made \(countOfGuesses) guesses"
            displayImage.isHidden = true
            
            if guessedCount == answers.count {
                hintLabel.isHidden = true
                guessCountLabel.isHidden = true
                statusLabel.text = "Congratulations! You Win! \nPlease play again"
                displayImage.isHidden = false
                displayImage.image = UIImage(named: assets[assets.count-1])
                playAgainButton.isHidden = false
                check=1;
            }
        }
    }

}
