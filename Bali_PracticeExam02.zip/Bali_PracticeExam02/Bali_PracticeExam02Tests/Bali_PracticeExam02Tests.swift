//
//  Bali_PracticeExam02Tests.swift
//  Bali_PracticeExam02Tests
//
//  Created by Dinesh Bali on 11/5/24.
//

import Testing
@testable import Bali_PracticeExam02

struct Bali_PracticeExam02Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
