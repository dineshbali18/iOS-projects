//
//  ViewController.swift
//  Bali_PracticeExam02
//
//  Created by Dinesh Bali on 11/5/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var loanTypeOL: UITextField!
    
    
    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var intrestRateOL: UITextField!
    
    
    @IBOutlet weak var yearsOL: UITextField!
    
    @IBOutlet weak var calculateBtn: UIButton!
    
    
    @IBOutlet weak var resetBtn: UIButton!
    
    
    var check:Bool = false;
    var count1:Int = 0;
    var count2:Int = 0;
    var count3:Int = 0;
    var count4:Int = 0;
    var countFinal:Int = 0;
    var image = ""
    
    
    var totalMonths=0.00;
    var monthlyInterestRate=0.00;
    var monthlyEMIPayment=0.00;
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if(loanTypeOL.text! != "" && amountOL.text! != "" && intrestRateOL.text! != "" && yearsOL.text! != ""){
            calculateBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
        
        calculateBtn.isEnabled = false;
        resetBtn.isEnabled = false;
    }

    @IBAction func calculateEMI(_ sender: Any) {
        totalMonths = Double(yearsOL.text!)! * 12;
        
        
        monthlyInterestRate = (Double(intrestRateOL.text!)! / 12.00)/100.00;
        
        monthlyEMIPayment = Double(amountOL.text!)! * (monthlyInterestRate * pow(1+monthlyInterestRate, totalMonths))/(pow(1+monthlyInterestRate,totalMonths)-1)
        
    }
    
    @IBAction func Reset(_ sender: Any) {
        loanTypeOL.text = ""
        amountOL.text = ""
        intrestRateOL.text = ""
        yearsOL.text = ""
        count1=0;
        count2=0;
        count3=0;
        count4=0;
        countFinal=0;
    }
    
    @IBAction func onChangeTextTerm(_ sender: Any) {
        if(yearsOL.text! == ""){
            check = false;
        }else{
            count1=1;
        }
        countFinal=count1+count2+count3+count4;
        print(countFinal)
        if(countFinal==4){
            calculateBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    @IBAction func intrestRateChanged(_ sender: Any) {
        if(intrestRateOL.text! == ""){
            check = false;
        }else{
            count2=1;
        }
        countFinal=count1+count2+count3+count4;
        if(countFinal==4){
            calculateBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    @IBAction func loanAmtChanged(_ sender: Any) {
        if(amountOL.text! == ""){
            check = false;
        }else{
            count3=1;
        }
        countFinal=count1+count2+count3+count4;
        if(countFinal==4){
            calculateBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    
    @IBAction func loanTypeChanged(_ sender: Any) {
        if(loanTypeOL.text! == ""){
            check = false;
        }else{
            count4=1;
        }
        if(loanTypeOL.text?.lowercased() == "car"){
            image = "Car"
        }else if(loanTypeOL.text?.lowercased() == "personal"){
            image = "Personal"
        }else if(loanTypeOL.text?.lowercased() == "home"){
            image = "Home"
        }
        countFinal=count1+count2+count3+count4;
        if(countFinal==4){
            calculateBtn.isEnabled = true;
            resetBtn.isEnabled = true;
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "resultSegue" {
            let destination = segue.destination as! ResultViewController;
            
            destination.image = image
            destination.amount = Double(amountOL.text!)!
            destination.intrest = Double(intrestRateOL.text!)!
            destination.type = loanTypeOL.text!
            destination.monthlyemi1 = Double(monthlyEMIPayment)
    
        }
    }
    
}

