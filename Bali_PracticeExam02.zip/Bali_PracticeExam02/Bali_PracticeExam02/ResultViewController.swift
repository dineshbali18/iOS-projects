//
//  ResultViewController.swift
//  Bali_PracticeExam02
//
//  Created by Dinesh Bali on 11/5/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var loanTypeOL: UILabel!
    
    
    @IBOutlet weak var amountOL: UILabel!
    
    
    
    @IBOutlet weak var interestOL: UILabel!
    
    
    @IBOutlet weak var monthlyemi: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    var type=""
    var amount = 0.0
    var intrest = 0.0
    var monthlyemi1 = 0.0
    var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        loanTypeOL.text! += " \(type)"
        amountOL.text! += " \(amount)"
        interestOL.text! += " \(intrest)%"
        monthlyemi.text! += String(format: "%.2f", monthlyemi1)
        imageOL.image = UIImage(named: image)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
